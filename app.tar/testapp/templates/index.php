<?php

declare(strict_types=1);

use OCP\Util;

Util::addScript(OCA\TestApp\AppInfo\Application::APP_ID, 'main');

?>

<div id="testapp"></div>
